package com.eatza.restaurantsearch.exception;

public class ItemNotFoundException extends Exception {
	
	
	public ItemNotFoundException() {
		super();
	}
	public ItemNotFoundException(String msg) {
		super(msg);
	}

}
