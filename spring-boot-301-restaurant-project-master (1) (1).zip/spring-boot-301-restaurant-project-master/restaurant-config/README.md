### Restaurant Config
This is a central place to store property files for restaurant microservices and it contains properties for all the profiles of services.





